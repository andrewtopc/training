-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 19 2021 г., 20:53
-- Версия сервера: 5.6.41
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `training_db`
--
CREATE DATABASE IF NOT EXISTS `training_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `training_db`;

-- --------------------------------------------------------

--
-- Структура таблицы `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_plan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student`
--

INSERT INTO `student` (`id`, `id_teacher`, `id_plan`) VALUES
(2, 4, 1),
(3, 5, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(64) NOT NULL,
  `salt` varchar(32) NOT NULL,
  `status` set('admin','student','teacher','director','kurator') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `salt`, `status`) VALUES
(1, 'admin', '805edb3c3a5e78ee3f18400eec43e0ccb79f9c06eba12702788460f862f7a644', '6a5f713b8524952b6379c6403389a64b', 'admin'),
(2, 'user', '8984e42985cc372fabda3f5d1daec3bbdb2c1213d629fb9b84831cfeb9a8937f', '4cc66c6c1bc670b442cfa1c1b7246e2d', 'student,teacher'),
(3, 'user2', 'c9a6dfe787c535535a7b3fdf293c1553f91ae761e4a67c53eaf4f9f742c9a79a', '4344d26eb60d63aeb42d851ff819ffb8', 'student'),
(4, 'teacher', 'a215f438af821831f1e0f20caeee2855fabfbc3f1da5ef6c578930f8cc0efa71', '616c4c881434d1f2b9639aec3a78e45a', 'teacher'),
(5, 't2', 'c92687f6e2dbbcb8ff4c186e31b2f77cc7d908c981b24d3e70823435407e38a1', '4a5b309ea61334372f6c5e96f385c8a9', 'teacher');

-- --------------------------------------------------------

--
-- Структура таблицы `userinfo`
--

CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `secondName` varchar(50) NOT NULL,
  `middleName` varchar(50) NOT NULL,
  `post` varchar(64) NOT NULL,
  `contacts` varchar(800) NOT NULL,
  `department` varchar(128) NOT NULL,
  `branch` varchar(256) NOT NULL,
  `category` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `userinfo`
--

INSERT INTO `userinfo` (`id`, `firstName`, `secondName`, `middleName`, `post`, `contacts`, `department`, `branch`, `category`) VALUES
(1, 'АдминИмя', 'АдминФамилия', 'АдминОтчество', 'АдминДолжность', 'АдминКонтактыБудущийЖСОНмассив', 'АдминОтдел', 'АдминФиллиал', 'АдминКатегория'),
(2, 'юАдминИмя', 'юАдминФамилия', 'юАдминОтчество', 'юАдминДолжность', 'юАдминКонтактыБудущийЖСОНмассив', 'юАдминОтдел', 'юАдминФиллиал', 'юАдминКатегория'),
(3, 'ю2', 'ю2', 'ю2', 'ю2', 'ю2', 'ю2', 'ю2', 'ю2'),
(4, 'учитель1И', 'учитель1Ф', 'учитель1О', 'учитель1Пост', 'учитель1Конт', 'учитель1Департ', 'учитель1Филиал', 'учитель1Катег'),
(5, 't2', 't2', 't2', 't2', 't2', 't2', 't2', 't2');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
