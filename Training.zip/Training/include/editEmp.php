<?php
  require_once "mysqli.php";
  require_once 'session.php';
  echo "<meta charset='utf-8'>";
  if($_SESSION["status"]<>'admin'){
      header("Refresh: 2; url=index.php");
      echo "123";
      exit;
  }
  if(!empty($_GET['id'])){
    if(!(db_connect())){
      $id = $_GET['id'];
      $resultInfo = mysqli_query($conn, "SELECT * FROM userinfo WHERE id = $id");
      $resultSingUp = mysqli_query($conn, "SELECT * FROM user WHERE id = $id");
      $rowInfo = mysqli_fetch_assoc($resultInfo);
      $rowSingUp = mysqli_fetch_assoc($resultSingUp);
      @mysqli_close($conn);
    }
  }
  if(!empty($_POST)){
  if(!(db_connect())){
  $firstName = $_POST["firstName"];
  $secondName = $_POST["secondName"];
  $middleName = $_POST["middleName"];
  $post = $_POST["post"];
  $contacts = $_POST["contacts"];
  $department = $_POST["department"];
  $branch = $_POST["branch"];
  $category = $_POST["category"];

  // $login = $_POST["login"];
  // $password = $_POST["password"];
  // $status = $_POST["status"];



	mysqli_query($conn, "UPDATE `userinfo` SET `firstName` = '$firstName', `secondName` = '$secondName', `middleName` = '$middleName',
     `post` = '$post', `contacts` = '$contacts', `department` = '$department', `branch` = '$branch', `category` = '$category' WHERE `userinfo`.`id` = $id");
	@mysqli_close($conn);
  }
  }
?>
<h2>Редактирование информации о сотруднике</h2>
<form method="post" enctype="multipart/form-data">
    <p><label>Имя сотрудника<textarea type="text" name="firstName" required ><?php echo $rowInfo['firstName']; ?></textarea></label></p>
    <p><label>Фамилия сотрудника <textarea type="text" name="secondName" required ><?php echo $rowInfo['secondName']; ?></textarea></label></p>
    <p><label>Отчество сотрудника<textarea name="middleName" required ><?php echo $rowInfo['middleName']; ?></textarea></label></p>
    <p><label>Должность сотрудника<input type="textarea" name="post" required value="<?php echo $rowInfo['post']; ?>"></label></p>
    <p><label>Контакты сотрудника<input type="textarea" name="contacts" required value="<?php echo $rowInfo['contacts']; ?>"></label></p>
    <p><label>Отдел сотрудника<input type="textarea" name="department" required value="<?php echo $rowInfo['department']; ?>"></label></p>
    <p><label>Филиал сотрудника<input type="textarea" name="branch" required value="<?php echo $rowInfo['branch']; ?>"></label></p>
    <p><label>Категория сотрудника<input type="textarea" name="category" required value="<?php echo $rowInfo['category']; ?>"></label></p>
    <hr>
    <p><label>Логин<textarea disabled="disabled" type="text" name="login" required ><?php echo $rowSingUp['login']; ?></textarea></label></p>
    <p><label>Пароль<textarea type="text" name="password" required ><?php echo $rowSingUp['password']; ?></textarea></label></p>
    <p>Статус</p>
    <select name="status" class = 'status'>
      <option value="admin" <?php if($rowSingUp['status']=='admin') echo 'selected' ?>>ЦПП</option>
      <option value="student" <?php if($rowSingUp['status']=='student') echo 'selected' ?>>Ученик</option>
      <option value="teacher" <?php if($rowSingUp['status']=='teacher') echo 'selected' ?>>Наставник</option>
      <option value="director" <?php if($rowSingUp['status']=='director') echo 'selected' ?>>Куратор</option>
      <option value="kurtor" <?php if($rowSingUp['status']=='kurtor') echo 'selected' ?>>Начальник отдела</option>
    </select>
    <input type="submit" value="Редактировать">
</form>
