<?php
require_once('mysqli.php');
if(!(db_connect())){
  $fio = $_POST['fio'];
  $sqlz2 = "SELECT post from userinfo where id = {$fio}";
  $sql2 = mysqli_query($conn, $sqlz2);
  $Data = array();
  while($result = mysqli_fetch_array($sql2, MYSQLI_ASSOC)){
      $Data[] = $result;
  }
  $html =  $Data[0]['post'];

  $sqlz = "SELECT department FROM userinfo WHERE id = {$fio}";
  $sql = mysqli_query($conn, $sqlz);
  foreach($sql as $row){
    $department .= $row['department'];
  }
  $sqlz3 = "SELECT firstName, secondName, middleName FROM userinfo LEFT JOIN `user` ON `userinfo`.id = `user`.id WHERE department = '${department}' AND `user`.status = 'director'";
  $sql3 = mysqli_query($conn, $sqlz3);
  foreach($sql3 as $row){
    $html2 .= $row['firstName'].' '.$row['secondName'].' '.$row['middleName'];
  }

  echo json_encode(array(
          'result'    => 'success',
          'html'      => $html,
          'html2'     => $html2
      ));
}

 ?>
