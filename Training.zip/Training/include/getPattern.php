<?php
require_once('mysqli.php');
if(!(db_connect())){
$pattern = $_POST['pattern'];
$sqlz = "SELECT * from pattern where title = '{$pattern}'";
$sql = mysqli_query($conn, $sqlz);

$systemarr = array();
foreach($sql as $row){
  array_push($systemarr, $row['title']);
}
$systemarr = array_unique($systemarr);
$html2 = $systemarr;

$html .= "<table border='1'>";
  $html .= '<tr>
  <td>№</td>
  <td>Проект, задание</td>
  <td>Форма обучения</td>
  <td>Период исполнения</td>
  <td>Дата начала исполнения</td>
  <td>Дата конца исполнения</td>
  <td>Куратор</td>
  <td>Ссылка на материалы в Confluence</td>
  </tr>';
foreach($sql as $row){
  $html .= '<tr>';
  $html .= '<td class="a">'.$row['id_string'].'</td><td>'.$row['task'].'</td><td>'.$row['form_education'].'</td><td>'.$row['execution_period'].'</td>'
  .'<td><input type="date" name="date_start'.$row['id_string'].'" id='.$row['id_string'].'></td>'.
  '<td><input type="date" name="date_end'.$row['id_string'].'" id='.$row['id_string'].'></td>'.'<td><select name="kurtor'.$row['id_string'].'" id='.$row['id_string'].'></select></td>'.'<td>'.$row['links'].'</td>';
  $html .= '</tr>';
}
$html .= "</table>";

echo json_encode(array(
        'result'    => 'success',
        'html'      => $html,
        'html2'     => $html2
    ));
}
 ?>
