<?php
	$host = "localhost";// хост
	$login = "root";	// логин / пароль пользователя
	$password = "";
	$db = "training_db";	// имя БД с которой будем работать

// объект соединения
	$conn = FALSE; // соединений на данном этапе нет

	/* Подключение к БД */
	function db_connect($host = "localhost", $login = "root", $password = "", $db = "training_db") {
		global $conn;
		$err = false; // ошибок нет

		$conn = @mysqli_connect($host  = "localhost", $login = "root", $password = "", $db = "training_db");
		if($conn)
			return $err; // connection OK
		else {
			//echo mysqli_connect_errno() . " - " . mysqli_connect_error(); // ошибка подключения
			return $err = true; // сообщаем об ошибке
		}
	}

	/* Закрытие соединения */
	function db_close() {
		@mysqli_close($GLOBALS["conn"]);
	}

	/* Регистрация пользователя */
	function add_usr($login, $password, $status, $firstName , $secondName , $middleName , $post , $contacts , $department , $branch , $category) {
		global $conn;
		$salt = get_salt();
		$password = hash("sha256", $password . $salt);

		$query = "INSERT INTO user VALUES(NULL, '$login', '$password', '$salt', '$status')";
		mysqli_query($conn, $query);

		$query2 = "INSERT INTO userinfo VALUES(NULL, '$firstName', '$secondName', '$middleName', '$post', '$contacts', '$department', '$branch', '$category')";
		mysqli_query($conn, $query2);
	}

#######################################################################################################

	// проверка пары логин/пароль
	function db_login($login, $password) {
		global $conn;
		$query = "SELECT * FROM user WHERE login = '$login'";

		$result = mysqli_query($conn, $query);
		if( mysqli_num_rows($result) != 0 ) {

			$row = mysqli_fetch_assoc($result);
			$password = hash("sha256", $password . $row["salt"]);

			return strcmp($password, $row["password"]);
		} else
			return TRUE;
	}



	//проверка на существование пользователя
	function db_check_usr($login) {
		global $conn;
		$query = "SELECT * FROM user WHERE login = '$login'";

		$result = mysqli_query($conn, $query);

		return mysqli_num_rows($result) != 0; // смотрим на количество строк результирующего запроса
	}

	// уникальная соль
	function get_salt() {
		return md5(uniqid() . time . mt_rand());
	}

// формируем из результурующей таблицы один массив(все записи в таблицы постепенно добавляем в один массив)
	function rowSet($result) {
		$fetchArray = array();

		while($row = mysqli_fetch_assoc($result))
			array_push($fetchArray, $row);

		return $fetchArray;
	}
	//?


	function get_user_status($login) {
		global $conn;
		$query = "SELECT status FROM user WHERE login = '$login'";



		$result = mysqli_query($conn, $query);

		return mysqli_fetch_array($result)["status"];
	}
/////////////////////////////////////////////////////////////////////////////
	function get_user_id($login) {
		global $conn;
		$query = "SELECT id FROM user WHERE login = '$login'";



		$result = mysqli_query($conn, $query);

		return mysqli_fetch_array($result)["id"];
	}

	function get_user($id = ""){
	global $conn;
	$query = $id === "" ? "SELECT * FROM userinfo" : "SELECT * FROM userinfo WHERE id = $id";



	$result = mysqli_query($conn, $query);
	if(mysqli_num_rows($result) > 0)
		return rowSet($result);
	}


/////////////////////////////////////////////////////////////////////////////


function update_password($login, $password, $status) {
	global $conn;
	$salt = get_salt(); //новый пароль - новая соль
	$password = hash("sha256", $password . $salt);

	$query = "UPDATE usr SET password = '$password', salt = '$salt', status = '$status' WHERE login = '$login'";

	mysqli_query($conn, $query);
}

function add_header($numberPlan, $pattern_title, $date_start_header, $date_end_header , $id_stundent , $id_teacher , $FIO_director, $post_now) {
	global $conn;

	$query = "INSERT INTO header VALUES('$numberPlan', '$pattern_title', '$date_start_header', '$date_end_header', '$id_stundent', '$id_teacher', '$FIO_director', '$post_now' )";
	mysqli_query($conn, $query);

}

function add_plan($numberPlan, $date_start, $date_end, $id_kurtor) {
	global $conn;

	$query = "INSERT INTO plan VALUES('$numberPlan', '$date_start', '$date_end', '$id_kurtor', NULL)";
	mysqli_query($conn, $query);

}
