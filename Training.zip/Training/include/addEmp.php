<?php
	require_once "session.php";
	require_once "mysqli.php";

  $html3 .= '<meta charset="utf-8">';
  $html3 .= '<link rel="stylesheet" href="/css/reg.css">';
  $html3 .= '<script src="/js/reg.js"></script>';
  echo $html3;

	$status = $_SESSION["status"];
	if(strcasecmp($status,"")==0){
	header("Location: /");}
	if(strcasecmp($status,"admin")!=0){
	header("Location: /");}

	if(!empty($_POST)) {
		if( !db_connect() ) {
			$user = htmlentities(mysqli_real_escape_string($conn, $_POST["login"]));
			$password = htmlentities(mysqli_real_escape_string($conn, $_POST["password"]));
			$repeatpassword = htmlentities(mysqli_real_escape_string($conn, $_POST["repeatpassword"]));
			$status = htmlentities(mysqli_real_escape_string($conn, $_POST["status"]));

      $firstName = htmlentities(mysqli_real_escape_string($conn,$_POST["firstName"]));
      $secondName = htmlentities(mysqli_real_escape_string($conn,$_POST["secondName"]));
      $middleName = htmlentities(mysqli_real_escape_string($conn,$_POST["middleName"]));
      $post = htmlentities(mysqli_real_escape_string($conn,$_POST["post"]));
      $contacts = htmlentities(mysqli_real_escape_string($conn,$_POST["contacts"]));
      $department = htmlentities(mysqli_real_escape_string($conn,$_POST["department"]));
      $branch = htmlentities(mysqli_real_escape_string($conn,$_POST["branch"]));
      $category = htmlentities(mysqli_real_escape_string($conn,$_POST["category"]));


			if (!empty($user || !empty($repeatpassword) || !empty($password)))
				if (!db_check_usr($user))
					if (strcmp($password, $repeatpassword) === 0)
						if(!empty($firstName) || !empty($secondName) || !empty($middleName) || !empty($post) || !empty($contacts) || !empty($department) || !empty($branch) || !empty($category)){
              if($status == "student"){
                
              }

							add_usr($user, $password, $status, $firstName , $secondName , $middleName , $post , $contacts , $department , $branch , $category);
						} else
							$error = "Введите полную информацию о сотруднике";
					else
						$error = "Пароли не совпадают";
				else
					$error = "Пользователь с таким именем уже существует";
			else
				$error = "Поля логин и пароль не могут быть пустыми";

			db_close();



			$ok = "Вы зарегистрировали нового пользователя";
		} else
			$error = "Ошибка при регистрации";
	}
?>




<body style="font-family:cursive;">


<main>
	<?php

		if(isset($error))
			echo <<<_OUT
				<div id="msg-error" class="msg msg-error">
					<div>$error</div>
					<div class="closed" onclick="msgClose('msg-error')">X</div>
				</div>
_OUT;
		else if(isset($ok))
			echo <<<_OUT
				<div id="msg-ok" class="msg msg-ok">
					<div>$ok</div>
					<div class="closed" onclick="msgClose('msg-ok')"></div>
				</div>
_OUT;
	?>

		<form id="reg" method="post">
				<h2 style="margin-top:1%;">Новый пользователь</h2>
				<input type="textarea" name="login" placeholder="Введите логин" required><br>
				<input type="password" name="password" placeholder="Пароль" required><br>
				<input type="password" name="repeatpassword" placeholder="Повторите пароль" required><br>
				<select name="status" id="elemId" onchange="funChange()">
          <option value="admin">ЦПП</option>
          <option value="student">Ученик</option>
          <option value="teacher">Наставник</option>
          <option value="director">Начальник отдела</option>
          <option value="kurtor">Куратор</option>
				</select>
        <div id ="txt" style="display:none">
        <input type="text" name="txt" size="20" id="txt_input">
        </div>

        <hr>
        <p><label>Имя сотрудника<textarea type="text" name="firstName" required ></textarea></label></p>
        <p><label>Фамилия сотрудника <textarea type="text" name="secondName" required ></textarea></label></p>
        <p><label>Отчество сотрудника<textarea name="middleName" required ></textarea></label></p>
        <p><label>Должность сотрудника<input type="textarea" name="post" required></label></p>
        <p><label>Контакты сотрудника<input type="textarea" name="contacts" required></label></p>
        <p><label>Отдел сотрудника<input type="textarea" name="department" required></label></p>
        <p><label>Филиал сотрудника<input type="textarea" name="branch" required></label></p>
        <p><label>Категория сотрудника<input type="textarea" name="category" required></label></p>
				<input type="submit" value="Зарегистрировать">
		</form>
	</main>


</body>
