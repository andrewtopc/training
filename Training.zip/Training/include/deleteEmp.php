<?php
  require_once 'session.php';
  if($_SESSION["status"]<>'admin'){
      header("Refresh: 2; url=index.php");
      echo "нет доступа";
      exit;
  }
  if(!empty($_GET['id'])){
      require_once "mysqli.php";
      if(!(db_connect())){
      $id = $_GET['id'];
      mysqli_query($conn, "DELETE FROM `user` WHERE id = $id");
      mysqli_query($conn, "DELETE FROM `userinfo` WHERE id = $id");
      mysqli_query($conn, "DELETE FROM `student` WHERE id = $id");
      @mysqli_close($conn);
      exit;
      }
  }
?>
