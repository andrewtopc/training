"use strict";

//удаление сообщения с экрана пользователя по нажатию на крестик в сообщении
function msgClose(id) {

	var msg = document.getElementById(id);
	var my_parent = msg.parentElement;

	my_parent.removeChild(msg);


}

	//var el=document.getElementById("elemId");

	function funChange(){
		var el=document.getElementById("elemId");
		var divTxt=document.getElementById("txt");
    var inpTxt=document.getElementById("txt_input");

		if(el.value!="student"){
			divTxt.style.display="none";
		}else{
			divTxt.style.display="block";
			inpTxt.value="";
		}
}
