"use strict";

//удаление сообщения с экрана пользователя по нажатию на крестик в сообщении
function msgClose(id) {

	var msg = document.getElementById(id);
	var my_parent = msg.parentElement;

	my_parent.removeChild(msg);


}

$(document).on('change', '.pattern', function() {
  $('.section3').css('display', "inline-block");
  document.querySelector(".selectPattern").style.display = "none";
  $('.section3').parent().append('<div class="tableinfo"></div>');
  $('.sectionTitle').parent().append('<input type="text" name="title" class="title">');
  $('.button').parent().append('<input type="submit" value="Создать новый план">');
  $('.qwe').parent().append('<input type="text" class="num" name="num">');
    var numItems = $('.a').length
    var pattern = $('.pattern').val();
    $.ajax({
        url: "include/getPattern.php", // куда отправляем
        type: "post", // метод передачи
        dataType: "json", // тип передачи данных
        data: { // что отправляем
            "pattern":   pattern
        },
        // после получения ответа сервера
        success: function(data){
            if(data.result == "success"){
              $('.tableinfo').append(data.html);
              $('.title').val(data.html2);
              $('.num').val(numItems);
            }
            else{
              $('.tableinfo').text('error');
            }
        }
    });
});

$(document).on('change', '.FIO_student', function() {
    var fio = $('.FIO_student').val();
    // $('.FIO_student').prop('disabled', true);
    $('.post').parent().append('<textarea name="post_now" class="post_now"></textarea>');
    $('.dir').parent().append('<textarea name="director" class="director"></textarea>');
    $.ajax({
        url: "include/getStudentInfo.php", // куда отправляем
        type: "post", // метод передачи
        dataType: "json", // тип передачи данных
        data: { // что отправляем
            "fio":   fio
        },
        // после получения ответа сервера
        success: function(data){
            if(data.result == "success"){
              $(".post_now").val(data.html);
              $('.director').val(data.html2);
            }
            else{
              $(".post_now").text('error');
            }
        }
    });
});
