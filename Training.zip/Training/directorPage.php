<?php
  require_once "include/session.php"; // на каждой странице
  require_once "include/mysqli.php";

  if(!empty($_SESSION["login"])) {
    if(!(db_connect())){
    $login = $_SESSION["login"];
    echo "<meta charset='utf-8'>";
    $sqlz2 = "SELECT * FROM `userinfo` WHERE (SELECT `user`.id from `user` where login = '$login') = `userinfo`.id";
    $sql2 = mysqli_query($conn, $sqlz2);
    $Data2 = array();
    while($result2 = mysqli_fetch_array($sql2, MYSQLI_ASSOC)){
        $Data2[] = $result2;
    }
    // $html3 .= '<br>'.$Data2[0]['firstName'].'<br>'.$Data2[0]['secondName'].'<br>'.$Data2[0]['middleName'].'<br>'.$Data2[0]['post'].'<br>'.$Data2[0]['contacts'].'<br>'.$Data2[0]['department'].'<br>'
    // .$Data2[0]['branch'].'<br>'.$Data2[0]['category'].'<br>';
    $department =  $Data2[0]['department'];


    echo $department;
    $sqlz = "SELECT firstName, secondName, middleName FROM `userinfo` WHERE department = '$department'";
    $sql = mysqli_query($conn, $sqlz);
    $Data = array();
    while($result = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
        $Data[] = $result;
    }
    foreach ($Data as $row) {
      $html .= '<br>'.$row['firstName'].'<br>'.$row['secondName'].'<br>'.$row['middleName'].'<br>';
    }

    echo <<<_OUT
      </br>
      <hr>
      <p>Список сотрудников</p>
_OUT;
    echo $html;


    }
  }

  else{
    header("Location: /");
  }
 ?>
