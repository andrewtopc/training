<?php
  require_once "include/session.php"; // на каждой странице
  require_once "include/mysqli.php";

  if(!empty($_SESSION["login"]) AND $_SESSION["login"] == "admin") {

    $user = $_SESSION["login"];
    require_once "block/menu.php";

    if(isset($_GET['employees'])){
      require_once('block/employees.php');
    }
    if(isset($_GET['analitics'])){
      require_once('block/analitics.php');
    }
    if(isset($_GET['createPlan'])){
      require_once('block/createPlan.php');
    }
  }
  else{
    header("Location: /");
  }
 ?>
