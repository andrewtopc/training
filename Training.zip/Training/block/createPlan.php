<?php
	require_once "include/session.php";
	require_once "include/mysqli.php";

  $html3 .= '<meta charset="utf-8">';
  $html3 .= '<link rel="stylesheet" href="/css/reg.css">';
  echo $html3;

	$status = $_SESSION["status"];
	if(strcasecmp($status,"")==0){
	header("Location: /");}
	if(strcasecmp($status,"admin")!=0){
	header("Location: /");}

	if(!empty($_POST)) {
		if( !db_connect() ) {

			$numberPlan = mt_rand(0, 4000);

			$sqlzap = "SELECT id_plan from header";
			$allnumbers = mysqli_query($conn, $sqlzap);
			$Data = array();
			while($result = mysqli_fetch_array($allnumbers, MYSQLI_ASSOC)){
					$Data[] = $result;
			}
			for($i=0;$i < count($Data);$i++)
			{
				if($Data[i] == $numberPlan)
				{
					$numberPlan = mt_rand(0, 4000);
					$i = 0;
				}
			}

			//header
			$pattern_title = htmlentities(mysqli_real_escape_string($conn, $_POST["title"]));
			$date_start_header = htmlentities(mysqli_real_escape_string($conn, $_POST["date_start_header"]));
			$date_end_header = htmlentities(mysqli_real_escape_string($conn, $_POST["date_end_header"]));
			$id_stundent = htmlentities(mysqli_real_escape_string($conn, $_POST["FIO_student"]));
			$id_teacher = htmlentities(mysqli_real_escape_string($conn, $_POST["teacher"]));
			$FIO_director = htmlentities(mysqli_real_escape_string($conn, $_POST["director"]));
			$post_now = htmlentities(mysqli_real_escape_string($conn, $_POST["post_now"]));

			add_header($numberPlan, $pattern_title, $date_start_header, $date_end_header , $id_stundent , $id_teacher , $FIO_director, $post_now);

			//plan
			$num = htmlentities(mysqli_real_escape_string($conn, $_POST["num"]));
			for($i = 1; $i < count($num)+2; $i++)
			{
				$date_start = htmlentities(mysqli_real_escape_string($conn, $_POST["date_start{$i}"]));
				$date_end = htmlentities(mysqli_real_escape_string($conn, $_POST["date_end{$i}"]));
				$id_kurtor = htmlentities(mysqli_real_escape_string($conn, $_POST["kurtor{$i}"]));
			add_plan($numberPlan, $date_start, $date_end, $id_kurtor);
			}

			db_close();



			$ok = "hqqq";
		} else
			$error = "ezx";
	}
?>




<body style="font-family:cursive;">
<script src="js/create.js"></script>

<main>
	<?php

		if(isset($error))
			echo <<<_OUT
				<div id="msg-error" class="msg msg-error">
					<div>$error</div>
					<div class="closed" onclick="msgClose('msg-error')">X</div>
				</div>
_OUT;
		else if(isset($ok))
			echo <<<_OUT
				<div id="msg-ok" class="msg msg-ok">
					<div>$ok</div>
					<div class="closed" onclick="msgClose('msg-ok')"></div>
				</div>
_OUT;
	?>

			</div>
				<form id="create" method="post">
				<h2 class="sectionTitle">Новый план</h2>
				<table border='1'>
				<tr>
					<td>
						<p>ФИО обучающегося:<select name="FIO_student" class = 'FIO_student'>
						<option value=' ' selected></option>
		<?php     if( !db_connect() ) {
							$sqlz2 = "SELECT * FROM `userinfo` LEFT JOIN `user` ON `userinfo`.id = `user`.id WHERE `user`.`status` = 'student' OR `user`.`status` = 'student,kurtor' OR `user`.`status` = 'kurtor,student' OR `user`.`status` = 'student,kurtor,teacher' OR `user`.`status` = 'student,teacher,kurtor' OR `user`.`status` = 'teacher,student,kurtor' OR `user`.`status` = 'kurtor,student,teacher' OR `user`.`status` = 'kurtor,teacher,student' OR `user`.`status` = 'teacher,kurtor,student' OR `user`.`status` = 'teacher,student' OR `user`.`status` = 'student,teacher'";
							$fio = mysqli_query($conn, $sqlz2);
							foreach ($fio as $stringDB) {
							echo "<option value='".$stringDB['id']."'>".$stringDB['firstName']." ".$stringDB['secondName']." ".$stringDB['middleName']."</option>";
						} }?>
					</select></p>
					</td>
				<td><p class="post">Текущая должность: </p></td>
				</tr>


				<tr>
				<td><p class="dir">Руководитель: </p></td>
				<td><p>ФИО наставника:<select name="teacher" class = 'countee'>
				<option value=' ' selected></option>
<?php     if( !db_connect() ) {
					$sqlz2 = "SELECT * FROM `userinfo` LEFT JOIN `user` ON `userinfo`.id = `user`.id WHERE `user`.`status` = 'teacher' OR `user`.`status` = 'teacher,kurtor' OR `user`.`status` = 'kurtor,teacher' OR `user`.`status` = 'student,kurtor,teacher' OR `user`.`status` = 'student,teacher,kurtor' OR `user`.`status` = 'teacher,student,kurtor' OR `user`.`status` = 'kurtor,student,teacher' OR `user`.`status` = 'kurtor,teacher,student' OR `user`.`status` = 'teacher,kurtor,student' OR `user`.`status` = 'teacher,student' OR `user`.`status` = 'student,teacher'";
					$fio = mysqli_query($conn, $sqlz2);
					foreach ($fio as $stringDB) {
					echo "<option value='".$stringDB['id']."'>".$stringDB['firstName']." ".$stringDB['secondName']." ".$stringDB['middleName']."</option>";
				} }?>
			</select></p></td>
			</tr>
			<tr>
			<td><p>Дата начала обучения: <input type="date" id="start_header" name="date_start_header"></p></td>
			<td><p>Дата конца обучения: <input type="date" id="end_header" name="date_end_header"></td>
			</tr>
				</table>


							<p class="selectPattern">Выберите шаблон:
							<select name="pattern" class = 'pattern'>
							<option value=' ' selected></option>
							<?php if( !db_connect() ) {
												$sqlz2 = "SELECT title FROM `pattern` group by title";
												$fio = mysqli_query($conn, $sqlz2);
												foreach ($fio as $stringDB) {
												echo "<option value='".$stringDB['title']."'>".$stringDB['title']."</option>";
											} }?>
							</select><p>
							<div class="qwe"></div>
							<div class="section3"></div>
							<div class="button"></div>
		</form>
	</main>


</body>
