<?php
	$status = $_SESSION["status"];
	echo $status;
?>
<header>
</header>