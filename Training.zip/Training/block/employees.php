<?php
	require_once 'include/session.php';
	require_once "include/mysqli.php";
	if(!(db_connect())){
	if(!empty($_GET["userinfo"])) {
		$userinfo = $_GET["userinfo"];
		$result = mysqli_query($conn, "SELECT * FROM userinfo");
	}
	else if(!empty($_GET["search"])) {
		$search = $_GET["search"];
		$category = htmlentities(mysqli_real_escape_string($conn, $_GET["category"]));
		$result = mysqli_query($conn, "SELECT * FROM userinfo WHERE LOCATE('$search', '$category') <> 0 LIMIT 10");
	}
	else{
		$result = mysqli_query($conn, "SELECT * FROM userinfo LIMIT 10");
	}
}
 ?>

	<link rel="stylesheet" href="css/admin.css">
<main>
<H1>Таблица сотрудников</h1>

  <form method="GET">
	<p>Поиск</p>
	<select name="category" class = 'category'>
		<option value="firstName">Имя</option>
		<option value="secondName">Фамилия</option>
		<option value="middleName">Отчество</option>
		<option value="post">Должность</option>
		<option value="department">Отдел</option>
		<option value="branch">Филиал</option>
		<option value="category">Категория</option>
	</select>
  <input name="search" type="text">
  <input type="submit" value="Искать"></p>
  </form>
  	<table border="1">
  		<a href='include/addEmp.php'>создать нового</a>
  		<tr>
  			<th>ФИО</th>
  			<th>Должность</th>
  			<th>Контакты</th>
  			<th>Отдел</th>
  			<th>Филиал</th>
  			<th>Категория</th>
  		</tr>
  		<?php //менять дальше!!!! сверху пример (чекнуть в таблице названия)
				if(!(db_connect())){
  		if(!empty($result)){
  			foreach($result as $key => $val) {
  				$id = $val["id"];
  				$firstName = $val["firstName"];
  				$secondName = $val["secondName"];
  				$middleName = $val["middleName"];
  				$post = $val["post"];
  				$contacts = $val["contacts"];
  				$department = $val["department"];
					$branch = $val["branch"];
					$category = $val["category"];
  				$art = <<<_OUT
  						<tr id="$id" class="emp">
  							<td>$firstName.$secondName.$middleName</td>
  							<td>$post</td>
  							<td>$contacts</td>
  							<td>$department</td>
  							<td>$branch</td>
  							<td>$category</td>
_OUT;
						echo $art;
						echo "<td><a href='include/deleteEmp.php?id=$id'>Удалить</a></td>";
						echo "<td><a href='include/editEmp.php?id=$id'>Редактировать</a></td>";
  				echo "</tr>";
  			}
  		@mysqli_close($conn);
  		}
		}
  		?>
  	</table>


</main>
