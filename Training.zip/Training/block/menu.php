<meta charset="utf-8">
<link rel="stylesheet" href="css/menu.css">
<script src="js/jquery-3.5.1.js"></script>
<script src="js/menu.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<header>
<ul id="menu">
<li><span>Меню</span>
<ul>
<li><a href="?employees">Сотрудники</a></li>
<li><a href="?analitics">Аналитика</a></li>
<li><a href="?createPlan">Создать план</a></li>
<li><a href="include/logout.php">Выход</a></li>
</ul>
</li>
</ul>
</header>
