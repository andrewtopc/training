<?php
require_once "include/session.php";
$status = $_SESSION["status"];

if(strcasecmp($status,"")==0) //не работает т.к запоминает последнюю сессию
{
	header("Location: /");
}
else
{
  //require_once 'block/head.php';
	  require_once 'include/mysqli.php';
	//	echo "<meta charset='utf-8'>";

switch($status) {
  case "student":
    header("Location: studentPage.php");
    break;
  case "admin":
	  header("Location: adminPage.php");
    break;
	case "teacher":
		  header("Location: teacherPage.php");
	    break;
	case "director":
			header("Location: directorPage.php");
			break;
	case "kurtor":
			header("Location: curatorPage.php");
			break;
  default:
					echo "<meta charset='utf-8'>";
					if($status == "student,teacher" || $status == "teacher,student"){
						$article = <<<_OUT
					  <button onClick='location.href="teacherPage.php"'>Наставник</button>
            <button onClick='location.href="studentPage.php"'>Ученик</button>
_OUT;
					}
					elseif($status == "student,kurtor" || $status == "kurtor,student"){
						$article = <<<_OUT
					  <button onClick='location.href="curatorPage.php"'>Куратор</button>
            <button onClick='location.href="studentPage.php"'>Ученик</button>
_OUT;
					}
					elseif($status == "teacher,kurtor" || $status == "kurtor,teacher"){
						$article = <<<_OUT
						<button onClick='location.href="curatorPage.php"'>Куратор</button>
					  <button onClick='location.href="teacherPage.php"'>Наставник</button>
_OUT;
					}
					else{
						$article = <<<_OUT
						<button onClick='location.href="studentPage.php"'>Ученик</button>
						<button onClick='location.href="curatorPage.php"'>Куратор</button>
						<button onClick='location.href="teacherPage.php"'>Наставник</button>
_OUT;
					}
		echo $status;
		echo $article;
		break;
}

}

//echo $_SESSION["status"];
?>
